DEBUG = True
# SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:1234@localhost:5432/bookshelf'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = 'thisisthesecretkey'
